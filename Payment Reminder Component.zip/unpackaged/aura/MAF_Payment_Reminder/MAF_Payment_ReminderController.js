({
	init : function(component, event, helper) {
		helper.getLPFData(component, event, helper);
	},
    
    handleChange : function(component, event, helper) {
        var selectedTimeline=event.getParam('value');
        component.set("v.timeline",selectedTimeline);
        
      //  component.set("v.showSpinner",true);
        var selectedPhaseId=component.get("v.selectedPhaseRecord.Id");
        var selectedMilstoneId=component.get("v.selectedMileStoneRecord.Id");
        var selectedUnitId=component.get("v.selectedUnitRecord.Id");
        var selectedTimeline=event.getParam('value');
        
        console.log('selectedPhaseId ',selectedPhaseId);
        console.log('selectedMilstoneId ',selectedMilstoneId);
        console.log('selectedUnitId ',selectedUnitId);
        console.log('selectedTimeline ',selectedTimeline);
        
        var DueDateStartRange = new Date();
        var DueDateEndRange = new Date();
        
        // helper.getLPFData(component, event, helper,selectedPhaseId,selectedMilstoneId,selectedUnitId,selectedTimeline,DueDateStartRange,DueDateEndRange);
        
        
    },
    
    searchLPFCharges : function(component, event, helper) {
        component.set("v.showSpinner",true);
        var selectedPhaseId=component.get("v.selectedPhaseRecord.Id");
        var selectedMilstoneId=component.get("v.selectedMileStoneRecord.Id");
        var selectedUnitId=component.get("v.selectedUnitRecord.Id");
        var selectedTimeline=component.get("v.timeline");
        
        console.log('selectedPhaseId ',selectedPhaseId);
        console.log('selectedMilstoneId ',selectedMilstoneId);
        console.log('selectedUnitId ',selectedUnitId);
        console.log('selectedTimeline ',selectedTimeline);
        
        var DueDateStartRange = new Date();
        var DueDateEndRange = new Date();
        
        helper.getLPFData(component, event, helper,selectedPhaseId,selectedMilstoneId,selectedUnitId,selectedTimeline,DueDateStartRange,DueDateEndRange);
    },
    
    processSelectedRows: function (component, event, helper) {
        var selectedRows = event.getParam('selectedRows');
        component.set('v.selectedRowList',selectedRows);
    },
    
    takeAction: function (component, event, helper) {
        console.log('-----take action----');
        var rowsSel = component.get('v.selectedRowList');
        var selectedArray=[];
        if(rowsSel==null || rowsSel.length==0){
            alert('No rows selected to process.');
            return;
        }
        else{
            for (var i = 0; i < rowsSel.length; i++){
                console.log('------rowsSel.length------');
                selectedArray.push(rowsSel[i].Id);
            }
            helper.sendEmailToCustomer(component, event,helper,selectedArray);
        }
        
    },
    
    createCases: function (component, event, helper) {
        var rowsSel = component.get('v.selectedRowList');
        var selectedArray=[];
        if(rowsSel==null || rowsSel.length==0){
            alert('No rows selected to process.');
            return;
        }
        else{
            component.get('v.showSpinner',true);
            for (var i = 0; i < rowsSel.length; i++){
                selectedArray.push(rowsSel[i].Id);
            }
            helper.createCaseHelper(component, event,helper,selectedArray);
        }
        
    },
    handlePhaseChange : function(component, event, helper) {
        var selectedPhaseId=event.getParam('value');
        // alert('selectedPhaseId'+JSON.stringify(selectedPhaseId));
    },
})
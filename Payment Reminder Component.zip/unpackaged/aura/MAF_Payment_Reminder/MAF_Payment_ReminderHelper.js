({
    getLPFData : function(component, event, helper,selectedPhaseId,selectedMilstoneId,selectedUnitId,selectedTimeline,DueDateStartRange,DueDateEndRange) {
        var action = component.get("c.getLPFCharges");
        console.log('helper selectedPhaseId ',selectedPhaseId);
        console.log('helper selectedMilstoneId ',selectedMilstoneId);
        console.log('helper selectedUnitId ',selectedUnitId);
        console.log('helper selectedTimeline ',selectedTimeline);
        console.log('helper DueDateStartRange ',DueDateStartRange);
        console.log('helper DueDateEndRange ',DueDateEndRange);
        action.setParams({
            "selectedPhaseId" : selectedPhaseId,
            "selectedMilstoneId" : selectedMilstoneId,
            "selectedUnitId" : selectedUnitId,
            "selectedTimeline" : selectedTimeline,
            "DueDateStartRange": DueDateStartRange,
            "DueDateEndRange": DueDateEndRange
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log(JSON.stringify(response.getReturnValue()));
            if (state === "SUCCESS") {
                var datalist=[]; 
                component.set('v.columns', [
                    {label: 'Name', fieldName: 'InstallmentLink', type: 'url',typeAttributes: { label: {fieldName: 'Name'}, target: '_blank' },sortable: true},
                    {label: 'Account', fieldName: 'AccountName', type: 'text'},
                    {label: 'Phase', fieldName: 'Phase__c', type: 'text'},
                    {label: 'Unit', fieldName: 'Unit__c', type: 'text'},
                    {label: 'Milestone', fieldName: 'MileStone__c', type: 'text'},
                    {label: 'Pending Amount', fieldName: 'Remaining_Amount__c', type: 'currency'},
                    {label: 'Due date', fieldName: 'Due_Date__c', type: 'date'},
                    {label: 'Total Amount', fieldName: 'Final_Amount__c', type: 'currency'},
                    {label: 'Opportunity', fieldName: 'OpportunityLink', type: 'url',typeAttributes: { label: {fieldName: 'OpportunityName'}, target: '_blank' },sortable: true},
                    {label: 'Reminders', fieldName: 'RemindersCount', type: 'number'},
                    {label: 'Reminder Type', fieldName: 'Reminder_Type__c', type: 'text'},
                    {label: 'Case', fieldName: 'CaseLink', type: 'url', typeAttributes: { label: {fieldName: 'CaseNumber'}, target: '_blank' },sortable: true},
                    {label: 'CaseFollowUp', fieldName: 'FollowupLink', type: 'url', typeAttributes: { label: {fieldName: 'CaseFollowupName'}, target: '_blank' },sortable: true}
                ]);
                var rows = response.getReturnValue().lstDataTableData;
                for (var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                    if (row.Opportunity__c){
                        row.OpportunityLink='https://mafpcommunities--new.lightning.force.com/'+row.Opportunity__c;
                        row.OpportunityName = row.Opportunity__r.Name;
                        row.AccountName=row.Opportunity__r.Account.Name;
                    }                    
                    row.InstallmentLink= 'https://mafpcommunities--new.lightning.force.com/'+row.Id;
                    if(row.Cases__r){
                        row.CaseLink='https://mafpcommunities--new.lightning.force.com/'+row.Cases__r[0].Id;
                        row.CaseNumber=row.Cases__r[0].CaseNumber;
                    }
                    if(row.Case_Followup__r){
                        row.FollowupLink='https://mafpcommunities--new.lightning.force.com/'+row.Case_Followup__r[0].Id;
                        row.CaseFollowupName=row.Case_Followup__r[0].Name;
                    }
                    
                    if(row.Tasks){
                        row.RemindersCount=row.Tasks.length;
                    }
                    
                }
                component.set("v.data", rows);
                component.set("v.showSpinner",false);
            }
            else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " +
                                    errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    sendEmailToCustomer : function(cmp, event,helper,selectedArray) {
        var selectedProjectId=cmp.get("v.selectedProjectId");
        var selectedPhaseId=cmp.get("v.selectedPhaseId");
        var selectedMilstoneId=cmp.get("v.selectedMilestoneId");
        var selectedUnitId=cmp.get("v.selectedUnitId");
        var startdueDate=cmp.find("duedateStart").get("v.value");
        var enddueDate=cmp.find("duedateEnd").get("v.value");
        
        var action = cmp.get("c.processSelectedLPF");
        action.setParams({"LPFrecordIds" : selectedArray});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue()==true){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "Email reminders has been sent successfully."
                    });
                    toastEvent.fire();
                    this.getLPFData(cmp, event,helper,selectedProjectId,selectedPhaseId,selectedMilstoneId,selectedUnitId,startdueDate,enddueDate);
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    createCaseHelper : function(cmp, event,helper,selectedArray) {
        var selectedProjectId=cmp.get("v.selectedProjectId");
        var selectedPhaseId=cmp.get("v.selectedPhaseId");
        var selectedMilstoneId=cmp.get("v.selectedMilestoneId");
        var selectedUnitId=cmp.get("v.selectedUnitId");
        var startdueDate=cmp.find("duedateStart").get("v.value");
        var enddueDate=cmp.find("duedateEnd").get("v.value");
        
        var action = cmp.get("c.createCaseForList");
        action.setParams({"LPFrecordIds" : selectedArray});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue()==true){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": "Cases has been created successfully."
                    });
                    toastEvent.fire();
                    this.getLPFData(cmp, event,helper,selectedProjectId,selectedPhaseId,selectedMilstoneId,selectedUnitId,startdueDate,enddueDate);
                }
                else{
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": "Unable to process your request."
                    });
                    toastEvent.fire();
                }
                
            }
            component.get('v.showSpinner',true);
        });
        $A.enqueueAction(action);
    },
})